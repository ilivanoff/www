<?php
   require('../includes/controller.inc.php');
   
   $oController = new Controller();
?>
