<p><?php echo $translation->Get('site.copyright', date('y'), '<a href="http://projectfondue.com/">Project Fondue</a>'); ?></p>
