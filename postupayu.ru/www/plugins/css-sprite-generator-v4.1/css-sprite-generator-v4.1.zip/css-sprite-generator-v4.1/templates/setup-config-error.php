<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <title>Setup Error</title>
      <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
      <link rel="icon" href="/favicon.ico" type="image/x-icon">
</head>

<body>
   <h1>Setup Error</h1>
   <p>Running in configuration mode. Make sure you're happy with the settings in &quot;includes/conf/app.inc.php&quot; and then set <code>$aConfig['setup'] = true;</code> in the file.</p>
</body> 
 
</html>
